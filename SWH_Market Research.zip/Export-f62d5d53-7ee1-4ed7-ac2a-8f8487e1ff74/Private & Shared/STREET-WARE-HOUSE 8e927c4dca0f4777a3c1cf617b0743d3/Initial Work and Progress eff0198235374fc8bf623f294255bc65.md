# Initial Work and Progress

1. Make a plan to start work towards building SWH :
    - Join people together
    - Define early stage tasks
    - Divide Work
    - set deadlines
2. Research about :
    - streetwear fashion and sneaker market
    - e-commerce
    - connectivity with users
    - collaborations with brands
    - revenue models
    - advertisement and marketing
    - Registration of SWH as a legitimate platform for selling goods

1. Early stage operation :
    - Building our e-commerce website ASAP
        - first including important features
    - Buy domain
    - Look up at registrations and legal procedures whatever needed
    - make a presentation to convinve brands to connect , display the potential benefits , data and revenue system