# Fashion Brands

Add the name of the brand you find wherever (small or big) and link to it’s website and the social media handles in the format specified :

- Name
    - Products (especially uniqueness)
    - Website link
    - Insta / Facebook handle