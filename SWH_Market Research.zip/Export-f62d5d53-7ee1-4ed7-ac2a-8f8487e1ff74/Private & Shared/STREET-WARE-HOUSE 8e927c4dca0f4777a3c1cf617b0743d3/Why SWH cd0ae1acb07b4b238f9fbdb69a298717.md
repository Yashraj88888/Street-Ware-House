# Why SWH?

## Customer POV :

There are hundreds of streetwear brands emerging in India with each of them selling a few common and a few niche products with high potential for sale.

 As customer , do we usually go to separate brand outlets or a place inclusive of all like a mall or a fashion street? , 90% of the time it’s a common place which would be access to everything else, why focus on searching rather than shopping.

SWH will provide you with :

1. A common place for all streetwear brands in India accessible to you so one does not have to skim through the internet to find an ideal one for their choice.
2. SWH will include all the products sold by the brands including clothing , footwear , jewelleries , sneakers and many more accessories.
3. SWH will connect you with brands which sell custom made products , like the brand names “courtside” which sells custom made nike sneakers with unique designs.
4. A separate common section displaying the best products from each brand will be a time saver.
5. Smart categorisation will help you to find the right products, like some brands sell products inspired from japanese art & culture with unique designs but how would that brand reach to millions of customers on it’s own.
6. Customer reviews and rating system would make sure the brand you are ordering from is trustworthy and you get an idea about the product quality.
7. Discussion forum for customers and fashion enthusiasts will help you connect more with the trend , get idea about brands and suggest your own ideas.

## Seller POV :

You are new brand who started a fashion brand with a hope to make it big. How are you gonna reach the customer base you aspire? It would take months of marketing to get recognised to a small customer base that too people who themselves take efforts to search around for such brands.

By registering your brand on SWH , you get :

1. Stand among the famous and top brands in your genre
2. High customer base (we are amazon for your boat)
3. Highlights for your special products
4. Access to SWH community to get suggestions
5. Higher customer reviews and a proper rating system to increase your product relevance
6. Separate marketing on SWH social media handles
7. ? Shipping services by SWH ?
8. Customer suggestions
9. Higher sales
10. If your product is different or less popular but has high growth potential , all you need is to get in the eyes of customers again and again , frequently highlight your products , and this would be much easier with SWH.

- Quality checks and barriers
- ensuring that the product recieved is of the same brand