# Revenue Model

- Commission of 5% on each sale done by the brand
- Listing fees
- Advertising fees for highlighting products on the website