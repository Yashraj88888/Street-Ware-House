# Categories

1. Clothing (Tshirts , shirts , pants , shawls , mufflers )
    - Theme inspired
    - Particular style
    - Biomaterial or nature friendly
    - Custom made
2. Accessories
    - caps
    - jewellery
    - wallets
    - belts
    - bags
    - purses
    
3. Footwear
    - Flipflops
    - Sneakers
    - loafers
    - crocs
    -