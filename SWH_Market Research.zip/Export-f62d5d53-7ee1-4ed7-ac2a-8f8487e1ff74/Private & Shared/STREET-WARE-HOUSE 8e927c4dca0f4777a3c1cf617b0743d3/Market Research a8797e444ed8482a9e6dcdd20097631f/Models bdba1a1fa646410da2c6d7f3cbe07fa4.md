# Models

1. Marketplace
    - connects seller with the customer using website and app
    - independent buyers and sellers
    - seller directly sells to the customer through the order placed by him on the platform
    - some merchant fees deducted and delivery fees

1. Inventory Model (more profitable)

for ex - amazon , flipkart

- Buys large quantity in less cost and lists on the website or app to sell it
- merchant fees and delivery fees
- Regulations by government to not use this model
- deep discounting hurts the offline commerce economy , as they are not able to match with the prices in accordance with the inventory firm

These middle firm also somtimes observe and find out the most selling item and it’s type and features , then manufacture a similar looking product and sell at cheaper price by different brand name or as amazon bestseller or amazon choice