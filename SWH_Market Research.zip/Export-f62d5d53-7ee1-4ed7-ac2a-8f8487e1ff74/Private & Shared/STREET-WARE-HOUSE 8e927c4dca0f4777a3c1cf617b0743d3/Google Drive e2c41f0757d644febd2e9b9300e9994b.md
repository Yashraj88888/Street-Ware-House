# Google Drive

Any files related to SWH can be stored here :

[https://drive.google.com/drive/folders/1SAimJ87KvQDuWuxU5V9qLopERJQh0mao?usp=sharing](https://drive.google.com/drive/folders/1SAimJ87KvQDuWuxU5V9qLopERJQh0mao?usp=sharing)