# Statistics & Analysis

Research and put info about :

1. Various market analysis methods
2. statistical methods
3. Growth indicators

etc

---

[Market Size](Statistics%20&%20Analysis%2035a872edc91a483d8a80f8b4d74c2dbe/Market%20Size%20870ac7c52ee24866b4865692c8b3a4eb.md)

[Technical Terms](Statistics%20&%20Analysis%2035a872edc91a483d8a80f8b4d74c2dbe/Technical%20Terms%20e998bdd75cf3442491333cadf8c66daa.md)